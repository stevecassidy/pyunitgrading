__author__ = 'Daniel Barnes'

from bottle import Bottle, template, static_file, request, response, HTTPError
import interface
#import users
from database import COMP249Db

application = Bottle()


@application.route('/')
def index():
    """Route for homepage"""
    db = COMP249Db()

    rows = interface.post_list(db, None, 50)

    return template('index', title='Home', posts=rows)


@application.route('/users/<usernick>')
def user(usernick):
    """Route for user page"""
    db = COMP249Db()

    avatar = interface.get_avatar(db, usernick)

    posts = interface.post_list(db, usernick, 50)

    return template('user', usernick=usernick, avatar=avatar, posts=posts)


@application.route('/mentions/<usernick>')
def mentions(usernick):
    """Route for list of posts that mention/reference a specified user"""
    db = COMP249Db()

    posts = interface.post_list_mentions(db, usernick)

    return template('mentions', usernick=usernick, posts=posts)


@application.route('/aboutus')
def aboutus():
    """Route for About Us page"""
    return template('aboutus')


@application.route('/static/<filename:path>')
def static(filename):
    """Route for static files, such as HTML, CSS, JS, etc."""
    return static_file(filename=filename, root='static')


if __name__ == '__main__':
    application.run(debug=True)
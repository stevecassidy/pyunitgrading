"""
@author: Daniel Barnes
"""

import collections
import re
import sqlite3


Post = collections.namedtuple('Post', 'id timestamp usernick avatar content')


def post_to_html(content):
    """Convert a post to safe HTML, quote any HTML code, convert
    URLs to live links and spot any @mentions or #tags and turn
    them into links.  Return the HTML string"""

    """
    Convert unsafe characters to HTML entities
    """
    content = content.replace('&', '&amp;')
    content = content.replace('<', '&lt;')
    content = content.replace('>', '&gt;')

    """
    Convert user mentions to links
    Mentions begin with '@' and are followed by, and end with, an alphanumerical character.
    Fullstops may occur in-between first and last nickname character - They may not occur at the end or start
    Examples: @daniel.barnes, @daniel, @dan.iel, @d.a.n.i.e.l
    """
    mention_re = re.compile('(@([a-zA-Z0-9]{1}[a-zA-Z0-9.]+[a-zA-Z0-9]{1}))')
    content = mention_re.sub(r"<a href='/users/\2'>\1</a>", content)

    """
    Convert URLs to links
    URLs begin with 'HTTP' or 'HTTPS', and are followed by 1 or more characters, and end on first occurring space
    """
    url_re = re.compile('(https?://[^\s]+)')
    content = url_re.sub(r"<a href='\1'>\1</a>", content)

    return content


def post_list(db, usernick=None, limit=50):
    """Return a list of posts ordered by date
    db is a database connection (as returned by COMP249Db())
    if usernick is not None, return only posts by this user
    return at most limit posts (default 50)

    Returns a list of tuples (id, timestamp, usernick, avatar,  content)
    """

    cur = db.cursor()

    query = 'SELECT id, timestamp, usernick, users.avatar, content ' \
            'FROM posts, users ' \
            'WHERE users.nick = posts.usernick '

    if usernick is not None:
        query += 'AND usernick=? '

    query += 'ORDER BY date("timestamp") DESC LIMIT ' + str(limit)

    if usernick is not None:
        executed = cur.execute(query, (usernick,))
    else:
        executed = cur.execute(query)

    rows = executed.fetchall()

    """
    Construct list of namedtuples for every fetched post.
    Namedtuples, unlike ordinary tuples, allow for access of fields by their name, instead of their index
    The content of each post will also be converted to the appropriate HTML
    """
    posts = []

    for row in rows:
        posts.append(
            Post(
                row[0],
                row[1],
                row[2],
                row[3],
                post_to_html(row[4])
            )
        )

    return posts


def post_list_mentions(db, usernick, limit=50):
    """Return a list of posts that mention usernick, ordered by date
    db is a database connection (as returned by COMP249Db())
    return at most limit posts (default 50)

    Returns a list of tuples (id, timestamp, usernick, avatar,  content)
    """

    query = 'SELECT id, timestamp, usernick, users.avatar, content ' \
            'FROM posts, users ' \
            'WHERE users.nick = posts.usernick ' \
            'ORDER BY date("timestamp") DESC'

    cur = db.cursor()

    rows = cur.execute(query).fetchall()

    posts = []

    for row in rows:
        # if post limit reached, break out of loop
        if len(posts) == limit:
            break

        # if user is mentioned in post content, append post to list of namedtuples
        if '@' + usernick in row[4]:
            posts.append(
                Post(
                    row[0],
                    row[1],
                    row[2],
                    row[3],
                    post_to_html(row[4])
                )
            )

    return posts


def post_add(db, usernick, message):
    """Add a new post to the database.
    The date of the post will be the current time and date.

    Return the id of the newly created post or None if there was a problem"""

    if len(message) > 150:
        return None

    cur = db.cursor()

    try:
        cur.execute("INSERT INTO posts(timestamp, usernick, content) VALUES (CURRENT_TIMESTAMP, ?, ?)",
                    (usernick, message))

        return cur.lastrowid
    except sqlite3.Error as error:
        print(error)
        return None


def get_avatar(db, usernick):
    """Return avatar for a specified user.

    Returns avatar URL if found, otherwise returns None
    """
    cur = db.cursor()

    avatar = cur.execute('SELECT avatar from users WHERE nick=?', (usernick,)).fetchone()

    if avatar:
        return avatar[0]
    else:
        return None
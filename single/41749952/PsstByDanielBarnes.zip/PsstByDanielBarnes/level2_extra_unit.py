"""
@author: Daniel Barnes
"""

import unittest

import interface
from database import COMP249Db


class ExtraUnitTests(unittest.TestCase):

    def setUp(self):
        # open an in-memory database for testing
        self.db = COMP249Db(':memory:')
        self.db.create_tables()
        self.db.sample_data(random=False)

        self.posts = self.db.posts

    def test_add_post(self):
        """Test that add_post works properly"""

        usernick = 'Bean'
        message = 'Test message. @Bobalooba Checkout Google http://google.com/ '

        # add post
        added_id = interface.post_add(self.db, usernick, message)

        # fetch post
        get_post = self.db.cursor().execute('SELECT content FROM posts WHERE id=?',
                                            (added_id,)).fetchone()

        # ensure message, along with contents, were successfully inserted
        self.assertEqual(get_post[0], message)

    def test_mentions(self):
        """Test that converting mentions to links works properly"""
        message = '@daniel.barnes. @daniel.@dan.iel, @d.a.n.i.e.l'

        prediction = "<a href='/users/daniel.barnes'>@daniel.barnes</a>. " \
                     "<a href='/users/daniel'>@daniel</a>." \
                     "<a href='/users/dan.iel'>@dan.iel</a>, " \
                     "<a href='/users/d.a.n.i.e.l'>@d.a.n.i.e.l</a>"

        message = interface.post_to_html(message)

        self.assertEqual(message, prediction)

if __name__ == "__main__":
    unittest.main()